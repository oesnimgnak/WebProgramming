package com.wp.goodsmanager;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class MyServletContextListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		ServletContextListener.super.contextDestroyed(sce);
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		ServletContextListener.super.contextInitialized(sce);

		ServletContext context = sce.getServletContext();
		
		DBConnectionInfo dbInfo = new DBConnectionInfo();
		dbInfo.setDriverClassName(
			context.getInitParameter("jdbc.driver_name"));
		dbInfo.setUrl(context.getInitParameter("jdbc.url"));
		dbInfo.setUsername(context.getInitParameter("jdbc.username"));
		dbInfo.setPassword(context.getInitParameter("jdbc.password"));
		
		context.setAttribute("db_info", dbInfo);
		
//		GoodsinfoDAO dao = new GoodsinfoDAOImpl(dbInfo);

		GoodsinfoDAO dao = new GoodsinfoDAObyDBCP(
				context.getInitParameter("dbcp_ref_name")
			);

		context.setAttribute("goodsinfo_dao", dao);
	}

}
