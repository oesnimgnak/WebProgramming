package com.wplab.fibonacci;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FibonacciServlet
 */
@WebServlet("/fibonacci.do")
public class FibonacciServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
    private BigInteger[] fiboNumbers = null;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FibonacciServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    @Override
   public void init() throws ServletException {
      // TODO Auto-generated method stub
      super.init();
      
      System.out.println("init()");
      fiboNumbers = new BigInteger[100];
      fiboNumbers[0] = new BigInteger("1");
      fiboNumbers[1] = new BigInteger("1");
      
      for(int i=2; i<100; i++) {
         fiboNumbers[i] = fiboNumbers[i-1].add(fiboNumbers[i-2]);
      }
   }

   /**
    * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
    */
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      // step #1. get request parameters
      request.setCharacterEncoding("UTF-8");
      String countStr = request.getParameter("count");
      int count = (countStr ==null || countStr == "") ? 0: Integer.parseInt(countStr);
      if(count> 100) count = 100;
      else if(count==1) count=2;
      
      // step #2. process business logic
      /*BigInteger[] fiboNumbers = null;  
      if (count != 0) {
      fiboNumbers = new BigInteger[count];
      fiboNumbers[0] = new BigInteger("0");
      fiboNumbers[1] = new BigInteger("1");
      
      for(int i=2; i<count; i++) {
         fiboNumbers[i] = fiboNumbers[i-1].add(fiboNumbers[i-2]);	// add가 새로운 객체를 반환 해줌.
      }
      }*/
      // step #3. output results to client
      response.setContentType("text/html;charset=UTF-8"); ;/*입력 값 중에 한글이 있을 경우도 있어서 먼저 인코딩 해줌.*/
      
      PrintWriter out = response.getWriter();
      out.println("<html>");
      out.println("<head>");
      out.println("<meta charset=\"UTF-8\">");
      out.println("<title>피보나치 수열 생성</title>");
      out.println("</head>");
      out.println("<body>");
      out.println("<h1>피보나치 수열 생성</h1><hr><br>");
      if(count==0) {
         out.println("<p>생성된 피보나치 수열 워소가 없습니다.,,</p>");
      }
      else {
         out.println("<p>피보나치 수열 원소 개수: " +count + "</p>");
         for(int i=0; i<count; i++) {
            out.println((i+1)+":"+fiboNumbers[i]+"</br>");
         }
      }
      
         out.println("</body>");
         out.println("</html>");
         out.close();
   }

   /**
    * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
    */
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      // TODO Auto-generated method stub
      doGet(request, response);
   }

   
}