package com.wplab.loginlogging;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.Out;

/**
 * Servlet implementation class LoginLoggingServler
 */
//@WebServlet({ "/LoginLoggingServler", "/login.do" })
@WebServlet(
name="login-logiing", urlPatterns= {"/login.do"}, 
initParams= {@WebInitParam(name="date-format", value = "yyyy-MM-dd"),
		@WebInitParam(name="logfile-prefix", value = "/wep/log/login-log-"),
		@WebInitParam(name="logfile-suffix", value = ".log")})
public class LoginLoggingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter logOut = null;
	/**
     * @see HttpServlet#HttpServlet()
     */
    public LoginLoggingServlet() {
    	
        super();
        
    }
    
    @Override
	public void destroy() {	
    	logOut.close();
		super.destroy();
	}

	@Override
	public void init() throws ServletException {	
		// TODO Auto-generated method stub
//		ServletConfig config = getServletConfig();	//서블릿 객체 값을 얻어옴
//		String prefix = config.getInitParameter("logfile-prefix");		//파라멘타 값 읽어옴
//		String suffix = config.getInitParameter("logfile-suffix");		//파라멘타 값 읽어옴
		String prefix = getInitParameter("logfile-prefix");		//파라멘타 값 읽어옴
		String suffix = getInitParameter("logfile-suffix");		//파라멘타 값 읽어옴
		
		SimpleDateFormat sdf =  
//				new SimpleDateFormat(config.getInitParameter("date-format"));//날짜 문자열을 만들어 달라
				new SimpleDateFormat(getInitParameter("date-format"));//날짜 문자열을 만들어 달라
		String logFileName = prefix + sdf.format(new Date()) + suffix;		//파일 네임 생성
		
		try {
			logOut = new PrintWriter(new FileWriter(logFileName, true));
		} catch (IOException e) {
			e.printStackTrace();
		}
		super.init();
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//step. #1. get request parameters
		request.setCharacterEncoding("UTF-8");
		
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		
		//step. #2. process business logic
		//user authentication

		String greeting = null;
		if(userid.equals("gdhong") && password.equals("1234")) {
			greeting = userid + "님, 반갑습니다!";
			
			if(logOut != null) {
				GregorianCalendar now = new GregorianCalendar();
				logOut.printf("%TF %TT - %s\n", now, now, userid);
			}
		} 

		//step. #3. output resultes to client
		
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("<meta charset=\"UTF-8\">");
		out.println("<title>Insert title here</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h1>로그인</h1><hr><br>");
		
		if (greeting == null) {
			out.println("<p>잘못된 userid 이거나 password 입니다. </p>");
			out.println("<p><a href='login.html'>로그인 화면 돌아가기</a></p>");
		}else {
			out.println("<p>" + greeting + "</p><br><br>");
			out.println("<p>현재 서비스 준비 중입니다...</p>");
		}
		out.println("</body></html>");
	}

}
