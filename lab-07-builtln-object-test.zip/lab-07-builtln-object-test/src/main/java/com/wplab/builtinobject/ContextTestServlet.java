package com.wplab.builtinobject;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ContextTestServlet
 */
@WebServlet("/context_test.do")
public class ContextTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContextTestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// step #1. get requset parameters
		request.setCharacterEncoding("UTF-8");
		
		// step #2. process business logic
//		ServletConfig config = getServletConfig();
//		ServletContext context = config.getServletContext();
		ServletContext context = getServletContext();
		
		// setp #3. output results to client
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html><head>");
		out.println("<title>ServletContext API Test</title>");
		out.println("</head>");
		out.println("<body style = 'padding-left: 100px';>");
		out.println("<header>");
		out.println("<h1>ServletContext API Test</h1><hr><br>");
		out.println("</header>");
		out.printf("<p>1. WAS Server Info: %s</p>\n", context.getServerInfo());
		out.printf("<p>2. Servlet Version: %s.%s</p>\n", context.getMajorVersion(), context.getMinorVersion());
		out.printf("<p>3. Web Context path: %s</p>\n", context.getContextPath());
		out.printf("<p>4. test_home.html 실제 위치: </p>\n",context.getRealPath("test_home.html"));
		out.printf("<br><br><br><br><br><hr>");
		out.printf("<p>5. 사이트 주소 : %s </p>\n", context.getInitParameter("site_address"));
		out.printf("<p>6. Contact Point : %s </p>\n", context.getInitParameter("contact_email"));
		
		out.println("</body></html>");
		
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				doGet(request, response);
	}

}
