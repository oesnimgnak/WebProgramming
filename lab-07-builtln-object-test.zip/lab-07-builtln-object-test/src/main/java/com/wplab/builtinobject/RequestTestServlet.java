package com.wplab.builtinobject;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RequestTestServlet
 */
@WebServlet("/request_test.do")
public class RequestTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RequestTestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// step #1. get requset parameters
		request.setCharacterEncoding("UTF-8");
		
		// step #2. process business logic
		
		// setp #3. output results to client
		response.setContentType("text/html; charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		out.println("<html><head>");
		out.println("<title>HttpServletReuqest API Test</title>");
		out.println("</head>");
		out.println("<body style = 'padding-left: 100px';>");
		out.println("<header>");
		out.println("<h1>Built-in Object Test</h1><hr><br>");
		out.println("</header>");
		out.printf("<p>1. 요청 URL: %s</p>\n", request.getRequestURI());
		out.printf("<p>2. 요청 Method: %s</p>\n", request.getMethod());
		out.printf("<p>3. 요청 쿼리 스트링: %s</p>\n", request.getQueryString());
		out.printf("<p>4. 요청 파라멘터: </p>\n");
		Enumeration<String> paramNames = request.getParameterNames();
		while (paramNames.hasMoreElements()) {
			String name= paramNames.nextElement();
			out.printf("&nbsp;&nbsp;&nbsp;&nbsp; %s = %s<br>\n" , name, request.getParameter(name));
		}
		out.printf("<p>5. 요청 헤더 정보: </p>\n");
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String name= headerNames.nextElement();
			out.printf("&nbsp;&nbsp;&nbsp;&nbsp; %s = %s<br>\n" , name, request.getHeader(name));
		}
		out.println("</body></html>");
		
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
