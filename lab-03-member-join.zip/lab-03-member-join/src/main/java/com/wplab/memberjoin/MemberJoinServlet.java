package com.wplab.memberjoin;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MemberJoinServlet
 */
@WebServlet("/join.do")
public class MemberJoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberJoinServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(
			HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		// step #1. get request parameters
		request.setCharacterEncoding("UTF-8");
		
		String name = request.getParameter("name");
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String inotice = request.getParameter("inotice");
		String cnotice = request.getParameter("cnotice");
		String dnotice = request.getParameter("dnotice");
		String job = request.getParameter("job");
			
		// step #2. process business logic
		// process member-join logic
		// -> store member record to DB
		// data validation
		
		String errorMsg = null;
		
		if (id.equalsIgnoreCase("admin")) {
			errorMsg = "사용할 수 없는 아이디입니다.";
		}
		
		// step #3. output results to client
		String viewName = null;
		
		if (errorMsg != null) {
			viewName = "error-page.jsp";
			request.setAttribute("error-msg", errorMsg);
		}
		else {
			viewName = "result-page.jsp";
		}
		
		RequestDispatcher view = request.getRequestDispatcher(viewName);
		view.forward(request, response);
			
/*
		response.setContentType("text/html;charset=UTF-8");
		
		PrintWriter out = response.getWriter();
		
		if (errorMsg != null) {
			out.println("<html>");
			out.println("<head>");
			out.println("<title>회원 가입</title>");
			out.println("</head>");
			out.println("<body style=\"padding-left: 100px;\">");
			out.println("<script>");		
			out.println("window.onload = () => {");		
			out.println("  alert('" + errorMsg + "');");		
			out.println("  window.history.back();");		
			out.println("}");		
			out.println("</script>");		
			out.println("</body></html>");
		}
		else {
			out.println("<html>");
			out.println("<head>");
			out.println("<title>회원 가입</title>");
			out.println("</head>");
			out.println("<body style=\"padding-left: 100px;\">");
			out.println("<h1>회원 가입 결과</h1><hr><br>");		
			out.println("<p>이름 : " + name + "</p>");		
			out.println("<p>아이디 : " + id + "</p>");		
			out.println("<p>비밀번호 : " + password + "</p>");		
			out.println("<p>성별 : " + (gender.equals("male") ? "남성" : "여성") + "</p>");		
			out.println("<p>공지 메일 : " + checkMailReception(inotice) + "</p>");		
			out.println("<p>광고 메일 : " + checkMailReception(cnotice) + "</p>");		
			out.println("<p>배송 메일 : " + checkMailReception(dnotice) + "</p>");		
			out.println("<p>직업 : " + job + "</p>");		
			out.println("<br><p>위의 내용으로 회원 가입이 완료되었습니다!</p>");		
			out.println("</body></html>");
		}
		
		out.close();
*/
	}
	
	private String checkMailReception(String notice) {
		String result = "수신 않함";
		
		if (notice != null && notice.equals("on")) {
			result = "수신함";
		}
		
		return result;
	}

}
