package com.wplab.scoreprocessing;

import java.util.ArrayList;
import java.util.List;

public class ScoresDO {
	
	private List<Integer> scores = null;	//동적으로 배열을 늘렸다 줄였다 가능.
	private double mean;
	private double sd;
	
	public int[] getScores() {
		int[] scoreArray = null;
		
		if(scores.size() > 0) {
			scoreArray = new int[scores.size()];
			for(int i =0; i <scores.size(); i++) {
				scoreArray[i] = scores.get(i);
			}
		}
		
		return scoreArray;
	}
	public void setScores(int[] scores) {
		if (this.scores == null) {
			this.scores = new ArrayList<Integer>();
		} else {
			this.scores.clear();
		}//없으면 만들어줘라
		for (int i=0; i<scores.length; i++) {
			this.scores.add(scores[i]);
		}
	}
	public void setScores(String[] scores) {
		if (this.scores == null) {
			this.scores = new ArrayList<Integer>();
		} else {
			this.scores.clear();
		}//없으면 만들어줘라
		for (int i=0; i<scores.length; i++) {//스트링값 가져와서 정수값으로 바꾼다음에 저장.
			this.scores.add(Integer.parseInt(scores[i]));
		}
	}
	public double getMean() {
		return mean;
	}
	public void setMean(double mean) {
		this.mean = mean;
	}
	public double getSd() {
		return sd;
	}
	public void setSd(double sd) {
		this.sd = sd;
	}
	
	

}
