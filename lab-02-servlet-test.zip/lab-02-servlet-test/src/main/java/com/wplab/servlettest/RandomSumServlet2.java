package com.wplab.servlettest;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RandomSunServlet
 */
@WebServlet("/randomsum2") /*@는 에노테이션: 전처리 명령어와 유사함. web.xml 파일에 서블릿을 등록 시켜준다.*/
public class RandomSumServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RandomSumServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 * request 처리해야하는 모든 정보가 있는
	 * response 응답메세지의 모든 정보가 있는 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Execute doGet method...");
		
		//process business logic
		//랜덤 넘버 생성 1~100 구간 합을 출력하는 프로그램
		int num = (int) (Math.random()* 100) +1;
		
		int sum = 0;
		for (int i=1; i<=num; i++) {
			sum += i;
		}
		
		//console 출력
		System.out.println("랜덤 숫자 :" + num);
		System.out.println("1부터 " + num + "까지 구간 합 : " + sum);
		
		//output processing results to client
		response.setContentType("text/html;charset=UTF-8"); /*text인데 html 형태로 보내겠다.utf-8이다.*/
		//response.setCharacterEncoding("UTF-8");
		
		//client 출력
		PrintWriter out = response.getWriter(); /*출력 스트림(response.getWriter())을 통해서 데이터를 보낸다*/
		out.println("<html><head></head><body>");
		out.println("<h1>랜덤 숫자 구간 합(2)</h1><hr>");
		out.println("<h3>랜덤 숫자 :" + num + "</h3>");
		out.println("<h3>1부터 " + num + "까지 구간 합 : " + sum+ "</h3>");
		out.println("</body></html>");
		
		out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Exeute service method...");
		super.service(req, resp);
	}
	
	

}
