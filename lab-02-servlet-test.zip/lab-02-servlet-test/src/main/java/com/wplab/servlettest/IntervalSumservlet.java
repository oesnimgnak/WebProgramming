package com.wplab.servlettest;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class IntervalSumservlet
 */
@WebServlet({ "/IntervalSumservlet", "/intervalsum.do" })
public class IntervalSumservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IntervalSumservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// step #1. get request parameters 파라멘터 값을 가져옴.
		request.setCharacterEncoding("UTF-8");/*입력 값 중에 한글이 있을 경우도 있어서 먼저 인코딩 해줌.*/
		
		String numStr = request.getParameter("num");
		int num = (numStr != null && numStr != "") ? Integer.parseInt(numStr) : 0;
		// step #2. process business logic 비지니스 로직 처리.
		int sum = 0;
		for (int i=1; 1<=num; i++) {
			sum += 1;
		}
		
		// step #3. output results to clinet 클라이언트에게 결과를 출력 해줌.
		response.setContentType("text/html;charset=UTF-8"); /*text인데 html 형태로 보내겠다.utf-8이다.*/
		
		//client 출력
		PrintWriter out = response.getWriter(); /*출력 스트림(response.getWriter())을 통해서 데이터를 보낸다*/
		out.println("<html><head></head><body>");
		out.println("<h1>구간 합 구하기</h1><hr>");
		out.println("<h3>입력 숫자 :" + num + "</h3>");
		out.println("<h3>1부터 " + num + "까지 구간 합 : " + sum+ "</h3>");
		out.println("<br><p><a href='interval-sum.html'>돌아가기</a></p>");
		out.println("</body></html>");
		
		out.close();
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
