package com.wplab.scoreprocessing;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ScoreProcessingServlet
 */
@WebServlet({ "/ScoreProcessingServlet", "/process.do" })
public class ScoreProcessingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ScoreProcessingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// strp #1. get request paramenters
		request.setCharacterEncoding("UTF-8");
		
		String[] scores = request.getParameterValues("scores");
		
		// 코드 집중화(A라는 코드가 있으면 A일만 하라는 것.)
		// step #2. process budiness logic(데이터 처리) 
		ScoresDO ScoresDo = new ScoresDO();
		ScoresDo.setScores(scores);
		
		ScoreProcessingService service = new ScoreProcessingService();
		service.processScores(ScoresDo);
		
		// step #3. output results to client (프레젠테이션 logic)
		request.setAttribute("scores", ScoresDo);
		
//		RequestDispatcher view = request.getRequestDispatcher(get.ServletContext().getContextPath()+"/output.do"); //절대 패스
		RequestDispatcher view = request.getRequestDispatcher("/output.do");//상대 패스 /output.do : 상위 머시기
		//포워딩
		view.forward(request, response);
		
		
	}

}
